#To use the toolbox, import all the zipped scripts into maya's "scripts" folder and run the following code.

import NateToolbox

reload(NateToolbox)
myTB = NateToolbox.NateToolbox()
myTB.create()